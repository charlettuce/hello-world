# defines how to draw each sprite as well as hitboxes and layering
