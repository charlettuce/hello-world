# Thehouse

Game to teach python programming to beginners.

Python version: 3.13.0

Important: (using cmd)

- use setup.bat to install correct pip modules
- use run.bat to test instance locally
