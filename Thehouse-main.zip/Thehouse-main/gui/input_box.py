import pygame
from sys import exit

class InputBox:
    def __init__(self, screen, position, size, bg_colour=(0,255,0), fg_colour=(255,255,255), text="Input: "):
        self.screen = screen

        self.active = False
        self.input_box = pygame.Rect(position, size)
        self.text = ''
        self.font = pygame.font.Font(None, 36)

    def update(self):
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                exit()

            # Handle mouse click to activate the input box
            if event.type == pygame.MOUSEBUTTONDOWN:
                if self.input_box.collidepoint(event.pos):
                    self.active = True
                else:
                    self.active = False

            # Handle key events for typing
            if event.type == pygame.KEYDOWN:
                if self.active:
                    if event.key == pygame.K_BACKSPACE:
                        self.text = self.text[:-1]  # Remove last character
                    elif event.key == pygame.K_RETURN:
                        print(self.text)
                        self.text = ''  # Clear the input box after enter
                        
                    else:
                        self.text += event.unicode  # Add typed character
        
        pygame.draw.rect(self.screen, (255,255,255), self.input_box)
        pygame.draw.rect(self.screen, (255,0,0) if self.active else (0,0,0), self.input_box, 2)

        txt_surface = self.font.render(self.text, True, (0, 0, 0))
        self.screen.blit(txt_surface, (self.input_box.x + 5, self.input_box.y + 5))

        # Draw the cursor (only if it's visible)
        if self.active:
            cursor_x = self.input_box.x + 5 + txt_surface.get_width()
            pygame.draw.line(self.screen, (0, 0, 0), (cursor_x, self.input_box.y + 5), (cursor_x, self.input_box.y + 45), 2)


    def change_bg_colour(self, bg_colour):
        self.bg_colour = bg_colour
        self.update()
    
    def change_fg_colour(self, fg_colour):
        self.fg_colour = fg_colour
        self.update()

