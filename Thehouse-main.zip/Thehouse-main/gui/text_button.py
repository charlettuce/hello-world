
import pygame

class TextButton(pygame.Rect):
    def __init__(self, screen, position, size, bg_colour=(0,255,0), fg_colour=(255,255,255), text="button"):
        super().__init__(position, size)
        self.screen = screen
        self.position = position
        self.size = size
        self.bg_colour = bg_colour
        self.fg_colour = fg_colour
        self.default_bg_colour = self.bg_colour
        self.text = text
        

        self.font = pygame.font.Font(None, 36)
        self.button_text = self.font.render(text, True, self.fg_colour)

        self.update()
        
    def update(self):
        # Check if the mouse is hovering over the button
        if self.collidepoint(pygame.mouse.get_pos()):
            self.bg_colour = (75,75, 75)  # Change button color when hovered
        else:
            self.bg_colour = self.default_bg_colour

        pygame.draw.rect(self.screen, self.bg_colour, self)
        self.screen.blit(self.button_text, self.button_text.get_rect(center=self.center))
        
        

    def change_bg_colour(self, bg_colour):
        self.bg_colour = bg_colour
        self.update()
    
    def change_fg_colour(self, fg_colour):
        self.fg_colour = fg_colour
        self.update()

