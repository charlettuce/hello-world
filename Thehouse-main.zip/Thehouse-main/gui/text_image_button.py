import pygame


from gui.text_button import TextButton

class TextImageButton(TextButton):
    def __init__(self, screen, position, size, image_path, bg_colour=(0,255,0), fg_colour=(255,255,255), text="button"):
        super().__init__(screen, position, size, bg_colour=bg_colour, fg_colour=fg_colour, text=text)

        self.load_image(image_path)
        self.update_image()
    
    def load_image(self, image_path):
        self.image_path =  image_path
        self.image =  pygame.image.load(self.image_path)

    def update_image(self):
        self.screen.blit(self.image, (self.position[0], self.position[1] + 100)) # placeholder